//
//  CollectionViewData.swift
//  UIDemo
//
//  Created by aravind-pt6209 on 29/03/23.
//

import Foundation
import AppKit

public var imagesSection1 = ["forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike","forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike","forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike",
                             "forest","andy", "poseiden","raven","sara", "storm", "spike"]
public var imagesSection2 = ["godzilla","mummy","sparkle"]
